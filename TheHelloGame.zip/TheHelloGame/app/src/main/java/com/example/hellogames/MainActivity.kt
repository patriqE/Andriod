package com.example.hellogames

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hellogames.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Hardcoded game list (from JSON)
    private val games = listOf(
        Game(9, "Sliding Puzzle", "https://upload.wikimedia.org/wikipedia/commons/4/48/15-Puzzle.jpg"),
        Game(3, "Sudoku", "https://uploads.guim.co.uk/2018/04/12/Sudoku_4035_easy.jpg"),
        Game(1, "Tic Tac Toe", "https://upload.wikimedia.org/wikipedia/commons/f/f6/Tic_Tac_Toe.png"),
        Game(6, "Game Of Life", "https://boingboing.net/images/gameofliffffff.jpg"),
        Game(8, "Simon", "https://images-eu.ssl-images-amazon.com/images/I/61w6y2tI8OL.png"),
        Game(2, "Hangman", "https://upload.wikimedia.org/wikipedia/commons/d/d6/Hangman-6.png"),
        Game(7, "Memory", "https://cdn.education.com/worksheet-image/126064/printable-memory-game-printable-board.png"),
        Game(10, "Mastermind", "https://1.bp.blogspot.com/-gu43i_aTL74/UBQovpfCmZI/AAAAAAAAAIY/1c_ddOHoIcg/s1600/robwill-mastermind.jpg"),
        Game(4, "Battleship", "https://t3.ftcdn.net/jpg/03/65/59/64/360_F_365596466_iGZRFRQd5DxbNICII4X0qDpLVed1JrBr.jpg"),
        Game(5, "Minesweeper", "https://www.surleweb.xyz/assets/images/minesweeper.png")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up window insets
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set up RecyclerView
        binding.gameRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.gameRecyclerView.adapter = GameAdapter(games) { game ->
            // Navigate to GameInfoActivity when a game is clicked
            val intent = Intent(this, GameInfoActivity::class.java)
            intent.putExtra("GAME_KEY", game)
            startActivity(intent)
        }
    }
}