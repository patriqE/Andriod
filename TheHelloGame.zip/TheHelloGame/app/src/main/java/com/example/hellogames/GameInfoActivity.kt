package com.example.hellogames

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.hellogames.databinding.ActivityGameInfoBinding

class GameInfoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameInfoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        
        // Get the game data from the intent
        val game: Game? = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("GAME_KEY", Game::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("GAME_KEY")
        }

        // Display game details (hardcoding some values as per the image)
        if (game != null) {
            binding.gameName.text = "Name: ${game.name}"
            binding.gameType.text = "Type: Mathematical"
            binding.gamePlayers.text = "No. players: 2"
            binding.gameYear.text = "Year: 1895"


        // Set up the "Know More" button to open a Wikipedia page
        binding.knowMoreButton.setOnClickListener {
            val gameNameForUrl = game.name.replace(" ", "_")
            val url = "https://en.wikipedia.org/wiki/$gameNameForUrl"
            val intent = Intent (Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
        }
    }
}