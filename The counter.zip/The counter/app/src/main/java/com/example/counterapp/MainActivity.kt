package com.example.counterapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.counterapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // View binding instance
    private lateinit var binding: ActivityMainBinding

    // Counter state
    private var counterValue = 0
    private var incrementStep = DEFAULT_INCREMENT_STEP

    companion object {
        private const val DEFAULT_INCREMENT_STEP = 1
        private const val BIG_INCREMENT_STEP = 10
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize view binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up window insets for edge-to-edge display
        setupWindowInsets()

        // Initialize UI
        initializeUI()

        // Set up button click listeners
        setupButtonListeners()
    }

    /**
     * Sets up window insets to handle system bars (status bar, navigation bar) padding.
     */
    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    /**
     * Initializes the UI by setting the initial counter value.
     */
    private fun initializeUI() {
        updateCounterDisplay()
    }

    /**
     * Sets up click listeners for all buttons.
     */
    private fun setupButtonListeners() {
        with(binding) {
            // Increment counter
            clickMeButton.setOnClickListener {
                incrementCounter()
            }

            // Reset counter to 0
            resetButton.setOnClickListener {
                resetCounter()
            }

            // Reverse counter (multiply by -1)
            reverseButton.setOnClickListener {
                reverseCounter()
            }

            // Set increment step to normal (1)
            normalButton.setOnClickListener {
                setIncrementStep(DEFAULT_INCREMENT_STEP)
            }

            // Set increment step to big (10)
            bigButton.setOnClickListener {
                setIncrementStep(BIG_INCREMENT_STEP)
            }
        }
    }

    /**
     * Increments the counter by the current increment step and updates the display.
     */
    private fun incrementCounter() {
        counterValue += incrementStep
        updateCounterDisplay()
    }

    /**
     * Resets the counter to 0 and updates the display.
     */
    private fun resetCounter() {
        counterValue = 0
        updateCounterDisplay()
    }

    /**
     * Reverses the counter value (multiplies by -1) and updates the display.
     */
    private fun reverseCounter() {
        counterValue = -counterValue
        updateCounterDisplay()
    }

    /**
     * Sets the increment step for the counter.
     * @param step The new increment step value.
     */
    private fun setIncrementStep(step: Int) {
        incrementStep = step
    }

    /**
     * Updates the counter display with the current counter value.
     */
    private fun updateCounterDisplay() {
        binding.counterText.text = counterValue.toString()
    }
}